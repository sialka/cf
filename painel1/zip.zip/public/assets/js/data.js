// Ip's
window.ip = {
  //adress : 'http://10.0.0.108:3000' // Desenvolvimento
  //adress: 'http://192.168.0.56:3000'    // Homologacao
  //adress: 'http://10.0.0.108:3000' // Producao
}

// Titulos dos Paineis
window.title = {
  panel1: 'Conferência de Fichas',
  panel2: 'Reserva de Roupas',
  panel3: 'Atendimento Cartão'
}

// Localidades
window.pimentas = [
  ['BAIRRO DOS PIMENTAS'],
  ['CIDADE ARACÍLIA'],
  ['CIDADE TUPINAMBÁ'],
  ['JARDIM ALICE'],
  ['JARDIM ANGÉLICA'],
  ['JARDIM ARAPONGAS'],
  ['JARDIM BRASIL'],
  ['JARDIM CUMBICA'],
  ['JARDIM DAS OLIVAS'],
  ['JARDIM GUILHERMINO'],
  ['JARDIM JACY'],
  ['JARDIM MONTE ALEGRE'],
  ['JARDIM NORMANDIA'],
  ['JARDIM NOVA CANAÃ'],
  ['JARDIM NOVA CUMBICA'],
  ['JARDIM OLIVEIRA'],
  ['JARDIM OTTAWA'],
  ['JARDIM SANTO AFONSO'],
  ['PARQUE DAS NAÇÕES'],
  ['PARQUE INDUSTRIAL'],
  ['PARQUE JANDAIA'],
  ['PARQUE SÃO MIGUEL'],
  ['PARQUE UIRAPURU'],
  ['SÍTIO SÃO FRANCISCO'],
  ['VILA ALZIRA'],
  ['VILA ANNY'],
  ['VILA DINAMARCA'],
  ['VILA PARAÍSO']
]
